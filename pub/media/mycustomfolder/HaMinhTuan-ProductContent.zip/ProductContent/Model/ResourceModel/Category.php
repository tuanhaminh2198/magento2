<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Dev\ProductContent\Model\ResourceModel;

use Magento\Catalog\Model\ResourceModel\Category as BaseCategory;

class Category extends BaseCategory
{
}
