<?php

declare(strict_types=1);

namespace Dev\ProductContent\Ui\Component\Category\Listing\ListingProduct;

use Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider;


class ListingProduct extends DataProvider
{
    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {

}
}
