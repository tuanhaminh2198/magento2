<?php

namespace Dev\Banner\Controller\Adminhtml\Category;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Dev\Banner\Model\PostFactory;
class InlineEdit extends \Magento\Backend\App\Action
{

    const ADMIN_RESOURCE = 'Magento_Cms::save';
    protected $postFactory;
    protected $pageRepository;
    protected $jsonFactory;

    public function __construct(
        Context $context,
        PostFactory $postFactory,
        JsonFactory $jsonFactory
    ) {
        parent::__construct($context);
        $this->postFactory = $postFactory;
        $this->jsonFactory = $jsonFactory;
    }
    public function execute()
    {
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];

        $postItems = $this->getRequest()->getParam('items', []);
//        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
//            return $resultJson->setData(
//                [
//                    'messages' => [__('Please correct the data sent.')],
//                    'error' => true,
//                ]
//            );
//        }

        foreach (array_keys($postItems) as $banner_id) {
            try {
                $banner = $this->postFactory->create();
                $banner = load($banner_id);
                $banner = setData($postItems[(string)$banner_id]);
                $banner = save();
            } catch (\Exception $e) {
                $messages[] = __('something went wrong');
                $error = true;
            }
        }
        return $resultJson->setData([
            'messages'=>$messages,
            'error'=>$error
        ]);
    }
}
