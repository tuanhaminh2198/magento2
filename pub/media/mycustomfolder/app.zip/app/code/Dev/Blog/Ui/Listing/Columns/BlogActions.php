<?php
namespace Dev\Blog\Ui\Listing\Columns;

class BlogActions extends \Magento\Ui\Component\Listing\Columns\Column{

    protected $url;

    public function __construct(\Magento\Framework\View\Element\UiComponent\ContextInterface $context,
    \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
    \Magento\Framework\UrlInterface $url,
    array $components = [], array $data = [])
    {
        $this->url = $url;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $item[$this->getData('name')] = [
                    'edit' => [
                        'href' => $this->url->getUrl('banner/index/actionbanner', ['id' => $item['blog_id']]),
                        'label' => __('Edit')
                    ]
                ];
            }
        }
        return $dataSource;
    }

}
