<?php
namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use PharIo\Version\Exception;

class Handle extends \Magento\Backend\App\Action{
    protected $_redirectFactory;
    protected $_bannerFactory;

    public function __construct(Context $context, \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory,
    \Dev\Banner\Model\BannerFactory $bannerFactory
    )
    {
        $this->_bannerFactory = $bannerFactory;
        $this->_redirectFactory = $redirectFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $dataBanner = $this->getRequest()->getPostValue();
//        var_dump($dataBanner['color']);
//        var_dump(arrayToObject($dataBanner['color']));
//        var_dump(json_encode($dataBanner['color']));
//        die();

        $param = $this->getRequest()->getParam('id');
        $id = null ;
        $newData = [
            'name' => $dataBanner['name'],
            'status' => $dataBanner['status'],
            'short_description' => $dataBanner['short_description'],
            'expired' => $dataBanner['expired'],
            'color' => json_encode($dataBanner['color'])
        ];
        if(!empty($dataBanner['banner_id'])){
            $id = $dataBanner['banner_id'];
            $time_update = date('Y-m-d H:i:s');
            $newData['updated_at'] = $time_update;
        }else if(isset($param)){
            $id = $param;
        }
        try {
            if (isset($dataBanner['image']) && is_array($dataBanner['image'])) {
                $strpos = strpos($dataBanner['image'][0]['url'],'/media/');
                $dataBanner['image'][0]['url'] = substr($dataBanner['image'][0]['url'],$strpos + 6);
                $dataBanner['image'][0]['url'] = trim($dataBanner['image'][0]['url'],'/');
                $newData['image'] = json_encode($dataBanner['image']);
//                var_dump(json_decode($newData['image']));
//                var_dump($newData['image']);
//                die();
            }
            if(isset($dataBanner['file']) && is_array($dataBanner['file'])){
                $newData['file'] = json_encode($dataBanner['file'][0]);
            }
            $this->_bannerFactory->create()->load($id)->addData($newData)->save();
            $this->messageManager->addSuccessMessage("You saved the banner.");
        }catch (Exception $exception){
            $this->messageManager->addErrorMessage("$exception->getMessage()");
        }
        return $this->_redirectFactory->create()->setPath('banner');
        // TODO: Implement execute() method.
    }
}
