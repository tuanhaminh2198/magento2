<?php
namespace Dev\Banner\Setup\Patch\Data;

use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;

class AddProductAttribute implements \Magento\Framework\Setup\Patch\DataPatchInterface{

    protected $moduleDataSetup;

    protected $eavSetupFactory;

    public function __construct(\Magento\Framework\Setup\ModuleDataSetupInterface $moduleDataSetup,
                                \Magento\Eav\Setup\EavSetupFactory $eavSetupFactory
    )
    {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
    }

    public function apply()
    {
        $eavSetup = $this->eavSetupFactory->create(['setup'=>$this->moduleDataSetup]);

        $eavSetup->addAttribute('catalog_product', 'product_banner', [
            'type' => 'int',
            'label' => 'Use Data Patch',
            'input' => 'text',
            'source' => '',
            'default' => 0,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'visible' => true,
            'used_in_product_listing' => true,
            'user_defined' => true,
            'required' => false,
            'group' => 'Content',
            'sort_order' => 80,
        ]);

    }

    public static function getDependencies()
    {
        return [];
        // TODO: Implement getDependencies() method.
    }

    public function getAliases()
    {
        return [];
        // TODO: Implement getAliases() method.
    }

}
