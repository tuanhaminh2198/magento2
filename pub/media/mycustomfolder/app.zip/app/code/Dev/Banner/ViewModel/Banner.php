<?php
namespace Dev\Banner\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;

class Banner implements ArgumentInterface
{
    protected $_bannerFactory;
    public function __construct(\Dev\Banner\Model\BannerFactory $bannerFactory) {
        $this->_bannerFactory = $bannerFactory;
    }

    public function getSomething()
    {
        return $this->_bannerFactory->create()->getCollection()->getData();
    }
}
