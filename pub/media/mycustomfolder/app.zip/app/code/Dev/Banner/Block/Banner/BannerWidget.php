<?php
namespace Dev\Banner\Block\Banner;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;


class BannerWidget extends Template implements BlockInterface
{
    protected $bannerCollectionFactory;

    public function __construct(
        Template\Context $context,
        \Dev\Banner\Model\ResourceModel\Banner\CollectionFactory $collectionFactory,
        array $data = []
    ) {
        $this->bannerCollectionFactory = $collectionFactory;
        $this->setTemplate('widget.phtml');
        parent::__construct(
            $context,
            $data
        );
    }

    protected function _beforeToHtml()
    {
        //init collection
       $collection = $this->bannerCollectionFactory->create();

       // Get enable images
        $banners = $collection->addFieldToFilter('status',['eq' => true])->getData();

        $this->setData('banners',$banners);
        $this->setData('mediaURL', $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'banner/tmp/image/');

        return parent::_beforeToHtml();
    }

}
