<?php
    namespace Dev\Banner\Model\Config;

    class Status implements \Magento\Framework\Option\ArrayInterface{

        public function toOptionArray()
        {
            return [
                ['value' => 1, 'label'=>'Active'],
                ['value' => 0, 'label'=>'Disable'],
            ];
            // TODO: Implement toOptionArray() method.
        }

    }
