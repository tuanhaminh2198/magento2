<?php
namespace Dev\Banner\Model\Config;
use Magento\Framework\Data\OptionSourceInterface;
class Color implements OptionSourceInterface
{
    protected $attributeOptionsList = [];
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $this->attributeOptionsList = [
               ['value'=>'red', 'label' => 'red'],
               ['value'=>'green', 'label' => 'green'],
               ['value'=>'yellow', 'label' => 'yellow'],
               ['value'=>'black', 'label' => 'black'],
               ['value'=>'violet', 'label' => 'violet'],
               ['value'=>'white', 'label' => 'white']
        ];
        return $this->attributeOptionsList;
    }
}
