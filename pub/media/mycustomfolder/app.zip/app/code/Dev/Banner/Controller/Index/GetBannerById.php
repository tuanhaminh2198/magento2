<?php
namespace Dev\Banner\Controller\Index;
use Magento\Framework\App\Action\Context;

class GetBannerById extends \Magento\Framework\App\Action\Action{
    protected $_pageFactory;
    protected $_coreRegistry;
    protected $_redirectFactory;

    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $pageFactory,
                                \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory
    )
    {
        $this->_redirectFactory = $redirectFactory;
        $this->_pageFactory = $pageFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        if(!isset($id) || !is_numeric($id)){
            $this->messageManager->addErrorMessage('id không hợp lệ');
            return $this->_redirectFactory->create()->setPath('banner');
        }else{
            $this->_coreRegistry->register('id', $id);
            return $this->_pageFactory->create();
        }
        // TODO: Implement execute() method.
    }

}
