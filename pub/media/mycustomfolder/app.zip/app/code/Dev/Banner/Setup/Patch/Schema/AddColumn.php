<?php

namespace Dev\Banner\Setup\Patch\Schema;
use Magento\Framework\DB\Ddl\Table;

class AddColumn implements \Magento\Framework\Setup\Patch\SchemaPatchInterface{

    protected $moduleDataSetup;

    public function __construct(\Magento\Framework\Setup\ModuleDataSetupInterface $moduleDataSetup)
    {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    public function apply()
    {
        $this->moduleDataSetup->startSetup();

        $this->moduleDataSetup->getConnection()->addColumn(
          $this->moduleDataSetup->getTable('banner'),'short_description',[
              'type' => Table::TYPE_TEXT,
              'length' => 255,
              'nullable' => true,
              'comment' => 'description'
            ]
        );

        $this->moduleDataSetup->endSetup();
        // TODO: Implement apply() method.
    }

    public static function getDependencies()
    {
        return [];
        // TODO: Implement getDependencies() method.
    }

    public function getAliases()
    {
        return [];
        // TODO: Implement getAliases() method.
    }

}
