<?php
    namespace Dev\Banner\Plugin\Block\Checkout;
    class LayoutProcessor{

        public function afterProcess(\Magento\Checkout\Block\Checkout\LayoutProcessor $subject, $jsLayout){

            $children = $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children'];

            //custom input radio
            $children['custom_radio'] = array_merge($children, [
               'component' => 'Magento_Ui/js/form/element/checkbox-set',
                'config' => [
                    'customScope' => 'shippingAddress.custom_attributes',
                    'template'=>'ui/form/field',
                    'elementTmpl' => 'ui/form/element/checkbox-set',
                    'options' => [
                        ['value'=>'0', 'label' => __('Giao hang nhanh')],
                        ['value'=>'1', 'label' => __('Giao hang tieu chuan')]
                    ],
                    'value' => '1'
                ],
                'label' => 'Custom Radio Field',
                'dataScope'=>'shippingAddress.custom_attributes.custom_radio',
                'provider' => 'checkoutProvider'
            ]);

            //custom input text
            $children['custom_text'] = array_merge($children,[
               'component' => 'Magento_Ui/js/form/element/abstract',
                'config' => [
                    'customScope' => 'shippingAddress.custom_attribute',
                    'template'=>'ui/form/field',
                    'elementTmpl' => 'ui/form/element/input',
                    'default' => 'khiemtv'
                ],
                'validation' => [
                    'required-entry' => true,
                    'max_text_length' => 255
                ],
                'dataScope' => 'shippingAddress.custom_attribute.custom_text',
                'provider'=>'checkoutProvider',
                'label' => 'Custom Text field',
                'visible' => true,
                'sortOrder' => 250,
                'id' => 'custom-text'
            ]);

            $children['custom_select'] = array_merge($children, [
                'component' => 'Magento_Ui/js/form/element/select',
                'config' => [
                    'customScope' => 'shippingAddress.custom_attributes.custom_select',
                    'template'=>'ui/form/field',
                    'elementTmpl' => 'ui/form/element/select',
                    'options' => [
                        ['value' => '1', 'label' => __('Yes')],
                        ['value' => '2', 'label' => __('No')]
                    ],
                    'value' => '1'
                ],
                'label' => 'Custom Select Field',
                'dataScope'=>'shippingAddress.custom_attributes.custom_select',
                'provider' => 'checkoutProvider',
                'visible' => true,
                'validation' => [],
                'sortOrder' => 270,
                'id' => 'custom-select'
            ]);

            $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children'] = $children;
            return $jsLayout;

        }

        public function aroundProcess($subject, $proceed, $jsLayout)
        {
            unset($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']['shippingAddress']['children']['before-form']['children']['newsletter']);
            $returnValue = $proceed($jsLayout);
            return $returnValue;
        }
    }
