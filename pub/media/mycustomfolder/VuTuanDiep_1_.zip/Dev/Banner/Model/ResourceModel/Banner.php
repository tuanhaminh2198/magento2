<?php
namespace Dev\Banner\Model\ResourceModel;
//
//use Magento\Catalog\Model\ResourceModel\Category as BaseCategory;
//
//class Banner extends BaseCategory
//{
//}

/**
 * Class Banner
 * @package Dev\Banner\Model\ResourceModel
 */
class Banner extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('banner', 'banner_id');
    }
//    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
//    {
//        $image = $object->getData('image');
//        if ($image != null){
//            $imageUploader = \Magento\Framework\App\ObjectManager::getInstance()
//                ->get('Dev\Banner\BannerImageUpload');
//            $imageUploader->moveFileFromTmp($image);
//        }
//        return $this;
//    }
}
