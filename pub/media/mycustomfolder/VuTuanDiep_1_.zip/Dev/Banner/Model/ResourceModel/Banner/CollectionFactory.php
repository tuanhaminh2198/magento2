<?php
namespace Dev\Banner\Model\ResourceModel\Banner;

class CollectionFactory
{
    /**
     * Object Manager instance
     *
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager = null;

    /**
     * @var
     */
    protected $_idFieldName = \Dev\Banner\Model\Banner::BANNER_ID;
    /**
     * @var mixed|string|null
     */
    protected $_instanceName = null;


    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param $instanceName
     */
    public function __construct(\Magento\Framework\ObjectManagerInterface $objectManager, $instanceName = '\\Dev\\Banner\\Model\\ResourceModel\\Banner\\Collection')
    {
        $this->_objectManager = $objectManager;
        $this->_instanceName = $instanceName;
    }


    /**
     * @param array $data
     * @return \#P#C\Dev\Banner\Model\ResourceModel\Banner\CollectionFactory._instanceName|mixed
     */
    public function create(array $data = array())
    {
        return $this->_objectManager->create($this->_instanceName, $data);
    }
}
