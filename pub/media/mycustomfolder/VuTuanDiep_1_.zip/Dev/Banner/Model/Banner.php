<?php
namespace Dev\Banner\Model;

use Magento\Framework\Model\AbstractExtensibleModel;
use Dev\Banner\Api\Data\BannerInterface;

/**
 * Class Banner
 * @package Dev\Banner\Model
 */
class Banner extends AbstractExtensibleModel implements BannerInterface
{
    const BANNER_ID = 'banner_id';
    const NAME = 'name';
    const DESCRIPTION = 'description';
    const IMAGE = 'image';
    const STATUS = 'status';
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Dev\Banner\Model\ResourceModel\Banner::class);
    }

    /**
     * {@inheritdoc}
     */
    public function getBannerId()
    {
        return $this->getData(self::BANNER_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setBannerId($banner_id)
    {
        $this->setData(self::BANNER_ID, $banner_id);
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * {@inheritdoc}
     */
    public function setName($name)
    {
        $this->setData(self::NAME, $name);
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getDescription()
    {
        return $this->getData(self::DESCRIPTION);
    }

    /**
     * {@inheritdoc}
     */
    public function setDescription($description)
    {
        $this->setData(self::DESCRIPTION, $description);
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getImage()
    {
        return $this->getData(self::IMAGE);
    }

    /**
     * {@inheritdoc}
     */
    public function setImage($image)
    {
        $this->setData(self::IMAGE, $image);
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * {@inheritdoc}
     */
    public function setStatus($status)
    {
        $this->setData(self::STATUS, $status);
        return $this;
    }
}
