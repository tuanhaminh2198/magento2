<?php

namespace Dev\Banner\Model\Config;

use Dev\Banner\Model\ResourceModel\Banner\CollectionFactory;
use Magento\Catalog\Helper\Image;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    protected $_loadedData;
    protected $collection;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        UrlInterface $urlBuilder,
        StoreManagerInterface $storeManager,
        Image $imageHelper,

//        $storeManager,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        $this->imageHelper = $imageHelper;
        $this->urlBuilder = $urlBuilder;
        $this->collection = $collectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
//    }
        $url = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $item) {
            if (isset($item['image'])) {
                $imageData = json_decode($item['image'], true);
                $item['image'] = [
                    [
                        'name'        => $imageData[0]['name'],
                        'url'         => $url . $imageData[0]['url'],
                        'previewType' => $imageData[0]['previewType'],
                        'id'          => $imageData[0]['id'],
                        'size'        => $imageData[0]['size']
                    ]
                ];
            }
            $this->_loadedData[$item->getId()] = $item->getData();
        }

        return $this->_loadedData;
    }
}
