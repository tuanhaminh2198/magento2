<?php

namespace Dev\Banner\Model;

use Magento\Framework\Api\SearchResults;
use Dev\Banner\Api\Data\BannerSearchResultInterface;

/**
 * Class BannerSearchResult
 * @package Dev\Banner\Model
 */
class BannerSearchResult extends SearchResults implements BannerSearchResultInterface
{

}
