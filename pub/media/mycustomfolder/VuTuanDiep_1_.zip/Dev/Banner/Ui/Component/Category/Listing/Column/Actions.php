<?php
///**
// * Copyright © Magento, Inc. All rights reserved.
// * See COPYING.txt for license details.
// */
//
//namespace Dev\Banner\Ui\Component\Category\Listing\Column;
//
//use Magento\Framework\Url;
//use Magento\Framework\View\Element\UiComponent\ContextInterface;
//use Magento\Framework\View\Element\UiComponentFactory;
//use Magento\Ui\Component\Listing\Columns\Column;
//
//class Actions extends Column
//{
//
//    /**
//     * @var Url
//     */
//    protected $_urlBuilder;
//
//    /**
//     * @var mixed|string
//     */
//    protected $_viewUrl;
//    /**
//     * @param ContextInterface $context
//     * @param UiComponentFactory $uiComponentFactory
//     * @param Url $urlBuilder
//     * @param $viewUrl
//     * @param array $components
//     * @param array $data
//     */
//    public function __construct(
//        ContextInterface   $context,
//        UiComponentFactory $uiComponentFactory,
//        Url                $urlBuilder,
//        $viewUrl = '',
//        array              $components = [],
//        array              $data = []
//    ) {
//        $this->_urlBuilder = $urlBuilder;
//        $this->_viewUrl = $viewUrl;
//        parent::__construct($context, $uiComponentFactory, $components, $data);
//    }
//
//    /**
//     * @param array $dataSource
//     * @return array|void
//     */
//    public function prepareDataSource(array $dataSource)
//    {
////     $dataSource = $this->getContext()->getDataProvider()->getData();
//        if (isset($dataSource['data']['items'])) {
//            foreach ($dataSource['data']['items'] as &$item) {
//                $name = $this->getData('$id');
//                if (isset($item['banner_id'])) {
//                    $item[$name]['view'] = [
//                        'href' => $this->_urlBuilder->getUrl($this->_viewUrl, ['id' => $item['banner_id']]),
//                        'target' => '_blank',
//                        'label' => __('View on Frontend')
//                    ];
//                    $item[$this->getData('name')] = [
//                        'edit' => [
//                            'href' =>  $this->_urlBuilder->getUrl('dev_banner/index/Edit'),['id' => $item['banner_id']],
//                            'label' => __('Edit')
//                        ],
//                        'remove' => [
//                            'href' => '/remove',
//                            'label' => __('Remove')
//                        ],
//                        'duplicate' => [
//                            'href' => '/duplicate',
//                            'label' => __('Duplicate')
//                        ],
//                    ];
//                }
//            }
//        }
//        return $dataSource;
//    }
//}

namespace Dev\Banner\Ui\Component\Category\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class Actions
 * @package Dev\Banner\Component\Category\Listing\Column
 */
class Actions extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * Actions constructor.
     * @param UrlInterface $urlBuilder
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        UrlInterface       $urlBuilder,
        ContextInterface   $context,
        UiComponentFactory $uiComponentFactory,
        array              $components = [],
        array              $data = []
    )
    {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $item[$this->getData('name')] = [
                    'edit' => [
                        'href' => $this->urlBuilder->getUrl('dev_banner/index/Edit', ['id' => $item['banner_id']]),
                        'label' => __('Edit')
                    ],
                    'remove' => [
                        'href' => '/remove',
                        'label' => __('Remove')
                    ],
                    'inline' => [
                        'href' => $this->urlBuilder->getUrl('dev_banner/index/Edit',['id' => $item['banner_id']]),
                        'label' =>__('Inline Edit')
                    ],
                    'view' => [
                        'href' => $this->urlBuilder->getUrl('dev_banner/index/index'),
                        'label' =>__('view')
                     ]
                ];
            }
        }

        return $dataSource;
    }
}
