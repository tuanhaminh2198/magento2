<?php

namespace Dev\Banner\Ui\Component\Category\Listing\Column;

use Magento\Catalog\Helper\Image;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class Custom extends Column
{
//    const ALT_FIELD = 'title';
//
//    /**
//     * @var \Magento\Store\Model\StoreManagerInterface
//     */
//    protected $storeManager;
//
//    /**
//     * @param ContextInterface $context
//     * @param UiComponentFactory $uiComponentFactory
//     * @param StoreManagerInterface $storeManager
//     * @param array $components
//     * @param array $data
//     */
//    public function __construct(
//        ContextInterface $context,
//        UiComponentFactory $uiComponentFactory,
//        Image $imageHelper,
//        StoreManagerInterface $storeManager,
//        array $components = [],
//        array $data = []
//    ) {
//        $this->storeManager = $storeManager;
//        $this->imageHelper = $imageHelper;
//        parent::__construct($context, $uiComponentFactory, $components, $data);
//    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     *
     * @return arraydataSource
     */
    public function __construct(ContextInterface $context, UiComponentFactory $uiComponentFactory, array $components = [], array $data = [])
    {
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {

        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');

                        $item['name'] = ['Diep : ' . $item['name']];
            }
        }
        return $dataSource;
    }
}
