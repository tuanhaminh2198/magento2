<?php

namespace Dev\Banner\Block\Adminhtml\Edit;

use Magento\Backend\Block\Widget\Form\Generic;

/**
 * Class Form
 * @package Dev\Banner\Block\Adminhtml\Edit
 */
class Form extends Generic
{
    /**
     * @return Form
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareForm()
    {
        $form = $this->_formFactory->create(
            [
                'data' => [
                    'id' => 'edit_form',
                    'action' => $this->getUrl('dev_banner/index/save'),
                    'method' => 'post',
                    'enctype' => 'multipart/form-data'
                ]
            ]
        );

        $form->setUseContainer(true);

        $fieldsets = $form->addFieldset(
            'field_set_example',
            ['legend' => __('General')]
        );
        $fieldsets->addField(
            'name',
            'text',
            [
                'name' => 'name',
                'label' => __('Name'),
                'title' => __('Name'),
                'required' => true,
                'value' => $this->getData('name')
            ]
        );
        $fieldsets->addField(
            'content',
            'textarea',
            [
                'name' => 'content',
                'title' => __('Content'),
                'label' => __('Content'),
                'required' => true
            ]
        );

        $fieldsets->addField(
            'status',
            'select',
            [
                'name' => 'status',
                'title' => __('Status'),
                'label' => __('Status'),
                'required' => true,
                'values' => [['value' => '1', 'label' => __('Pending')], ['value' => 2, 'label' => __('Publish')]]
            ]
        );
        $id = $this->getRequest()->getParam('id', false);
        $banner = $this->bannerModel->create()->load($id);
        $form->setValues($banner->getData);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
