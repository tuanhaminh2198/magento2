<?php

namespace Dev\Banner\Block\Adminhtml;

/**
 * Class Edit
 * @package Dev\Banner\Block\Adminhtml
 */
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Internal constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();

        /**
         * Xóa các button không cần thiết
         */
        $this->buttonList->remove('back');
        $this->buttonList->remove('reset');
        $this->buttonList->remove('delete');
        $this->_objectId = 'example';
        $this->_blockGroup = 'Dev_Banner';
        /**
         *  Đường dẫn đến file hiện tại, tính từ thư mục bên trong thư mục block,
         *  Nếu có nhiều thư mục có thể phân cách nhau bởi dấu gạch dưới
         *  Ví dụ: adminhtml_post_tab
         */
        $this->_controller = 'adminhtml';
    }

    /**
     * Get header text
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        return __('New Post');
    }

    /**
     * Save path url
     * @return string
     */
    public function getSaveUrl()
    {
        return $this->getUrl('dev_banner/index/save');
    }
}
