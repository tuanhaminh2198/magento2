<?php
namespace Dev\Banner\Block;

use Dev\Banner\Model\BannerRepository;
use Dev\Banner\Model\ResourceModel\Banner\CollectionFactory;
use Magento\Framework\View\Element\Template;

class Index extends \Magento\Framework\View\Element\Template
{
    protected $BannerFactory;
    private $bannerRepository;

    public function __construct(Template\Context $context, CollectionFactory $bannerFactory, BannerRepository $bannerRepository, \Magento\Framework\App\Request\Http $request)
    {
        $this->request = $request;
        $this->bannerRepository = $bannerRepository;
        $this->BannerFactory = $bannerFactory;

        parent::__construct($context);
    }
    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */

    public function getBanner()
    {
        $id = $this->request->getParam('id');
        $a = $this->bannerRepository->getById($id);
        echo "<pre>";
        var_dump($a->getData());
        echo "</pre>";
//        $data = $this->$a->getData();
//        var_dump($this->getRequest()->getParam('id'));
//        return __('Hello World');
//        $banner = $this->bannerRepository->create();
//        return $banner->getBanner();
//
// return $banner;
    }
//    public function __construct(Template\Context $context, array $data = [])
//    {
//        parent::__construct($context, $data);
//    }

    public function getTitle()
    {
//        die("ddssd");
        return __('HelloWorld!');
    }

}
