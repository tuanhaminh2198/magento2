<?php

namespace Dev\Banner\Block;

use Dev\Banner\Model\BannerRepository;
use Dev\Banner\Model\ResourceModel\Banner\CollectionFactory;
use Magento\Catalog\Helper\Image;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Store\Model\StoreManagerInterface;

/**
 *
 */
class Images extends \Magento\Framework\View\Element\Template
{
    /**
     *
     */
    const ALT_FIELD = 'title';

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var
     */
    protected $BannerFactory;
    /**
     * @var
     */
    private $bannerRepository;
    /**
     * @var
     */
    protected $_orderCollectionFactory;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param Image $imageHelper
     * @param UrlInterface $urlBuilder
     * @param StoreManagerInterface $storeManager
     * @param array $components
     * @param array $data
     */

    public function __construct(
        Template\Context $context,
        CollectionFactory $bannerFactory,
        BannerRepository $bannerRepository,
        \Magento\Framework\App\Request\Http $request,
        StoreManagerInterface $storeManager,
        array $data = [],
        CollectionFactory $orderCollectionFactory
    ) {
        $this->request = $request;
        $this->storeManager = $storeManager;
        $this->bannerRepository = $bannerRepository;
        $this->BannerFactory = $bannerFactory;
        parent::__construct($context, $data);
        $this->_orderCollectionFactory = $orderCollectionFactory;
        parent::__construct($context);
    }
//    public function getOrderCollectionByCustomerId($bannerId)
//    {
//        $collection = $this->_orderCollectionFactory()->create($bannerId)
//            ->addFieldToSelect('image'),
//            ->addFieldToFilter('image',
//                ['in' => $this->_orderConfig->getVisibleOnFrontStatuses()]
//            )
//            ->setOrder(
//                'created_at',
//                'desc'
//            );
//
//        return $collection;
//
//    }
    /**
     * @return void
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getImages()
    {
        $a = $this->BannerFactory->create();
        $url = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        foreach ($a as $item) {
            if ($item['status'] == 'activetop' || $item['status'] == 'activebottom') {
                $imageData = json_decode($item['image'], true);
                $item['image'] = [
                        [
                            'name' => $imageData[0]['name'],
                            'url' => $url . $imageData[0]['url'],
                            'previewType' => $imageData[0]['previewType'],
                            'id' => $imageData[0]['id'],
                            'size' => $imageData[0]['size']
                        ]
                    ];
                echo '<img src=' . $item['image'][0]['url'] . '>';
            } if($item['status'] == 'activebottom') {
                ///em da dao phan tu trong main anh với chữ
                echo '<style>.columns .column.main { display: flex;flex-direction: column-reverse;}</style>';
            } elseif ($item['status'] == 'inactive') {
                echo "";
            }
        }
    }

    public function getOrderCollection($bannerId)
    {
        $collection = $this->_orderCollectionFactory()->create($bannerId)
            ->addFieldToSelect('*')
            ->addFieldToFilter(
                'status',
                ['in' => $this->_orderConfig->getVisibleOnFrontStatuses()]
            );

        return $collection;
    }
    /**
     * @param $row
     * @return null
     */
}
