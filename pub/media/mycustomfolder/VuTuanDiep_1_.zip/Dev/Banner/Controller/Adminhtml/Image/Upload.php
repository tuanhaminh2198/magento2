<?php

namespace Dev\Banner\Controller\Adminhtml\Image;

use Dev\Banner\Model\ImageUploader;
use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;

/**
 *
 */
class Upload extends \Magento\Backend\App\Action
{

    /**
     * @var ImageUploader
     */
    protected $imageUploader;

    /**
     * @param Action\Context $context
     * @param ImageUploader $imageUploader
     */
    public function __construct(
        Action\Context $context,
        ImageUploader  $imageUploader
    ) {
        parent::__construct($context);
        $this->imageUploader = $imageUploader;
    }

    public function execute()
    {
        $image = $this->_request->getParam('param_name', 'image');

        try {
            $result = $this->imageUploader->saveFileToTmpDir($image);
            $result['cookie']=[
                'name' => $this->_getSession()->getName(),
                'value' => $this->_getSession()->getName(),
                'lifetime' => $this->_getSession()->getName(),
                'path' => $this->_getSession()->getName(),
            ];
        } catch (\Exception $e) {
            $result = ['error' => $e->getMessage(), 'error-code' => $e->getCode()];
        }
        return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData($result);
    }
}
