<?php

namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Edit
 * @package Dev\Banner\Controller\Adminhtml\Index
 */
class Edit extends Action
{
    const ALT_FIELD = 'title';
    /**
     * @var
     */
    protected $storeManager;
    protected $collection;
    /**
     * @return mixed
     */

    public function getData()
    {
        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        $items = $this->collection->getItems();
        $url = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        foreach ($items as $item) {
            $data = $item->getData();
            if (isset($data['image'])) {
                $imageData = json_decode($data['image'], true);
                $data['image'] = [
                    [
                        'name'        => $imageData[0]['name'],
                        'url'         => $imageData[0]['url'],
                        'previewType' => $imageData[0]['previewType'],
                        'id'          => $imageData[0]['id'],
                        'size'        => $imageData[0]['size']
                    ]
                ];
            }
            $url = '';
            if ($item[$items] != '') {
                $url = $this->storeManager->getStore()->getBaseUrl(
                    UrlInterface::URL_TYPE_MEDIA
                ) . $item['image'][0]['url'];
            }
            $item[$items . '_src'] = $url;
            $item[$items . '_orig_src'] = $url;
            $this->_loadedData[$item->getId()] = $data;
        }
        return $this->_loadedData;
    }

    public function execute()
    {
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->getConfig()->getTitle()->prepend(__('Edit Columns'));
        return $resultPage;
    }
}
