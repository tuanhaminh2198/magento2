<?php

namespace Dev\Banner\Controller\Index;

     class View extends \Magento\Framework\App\Action\Action
     {

         /**
          * @var \Magento\Framework\View\Result\PageFactory
          */
         protected $resultPageFactory;

         /**
          * Request instance
          *
          * @var \Magento\Framework\Registry
          */
         protected $_coreRegistry;

         /**
          * @param \Magento\Framework\App\Action\Context $context
          * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
          */
         public function __construct(
             \Magento\Framework\App\Action\Context $context,
             \Magento\Framework\Registry $coreRegistry,
             \Magento\Framework\View\Result\PageFactory $resultPageFactory
         )
         {

             $this->resultPageFactory = $resultPageFactory;

             $this->_coreRegistry = $coreRegistry;
             parent::__construct($context);
         }

         /**
          * Loads page content
          *
          * @return \Magento\Framework\View\Result\Page
          */
         public function execute()
         {
             $bannerId = (int)$this->getRequest()->getParam('id', false);
             $this->_coreRegistry->register('bannerId', $bannerId);

             $resultPage = $this->resultPageFactory->create();
             $resultPage->getConfig()->getTitle()->set(__('All Categories'));

             return $resultPage;
         }

     }
