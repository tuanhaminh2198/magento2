<?php

namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action;

/**
 * Class AddNew
 * @package Dev\Banner\Controller\Adminhtml\Index
 */
class AddNew extends Action
{
    public function execute()
    {
//        $this->_controller = 'adminhtml_layout';
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->getConfig()->getTitle()->prepend(__('Add New Post'));
        return $resultPage;

    }

}
