<?php
//
//namespace Dev\Banner\Controller\Adminhtml\Index;
//
//use Magento\Backend\App\Action\Context;
//use Magento\Framework\Controller\Result\JsonFactory;
//use Dev\Banner\Model\BannerFactory;
//use Dev\Banner\Model\ResourceModel\Banner as BannerResourceModel;
//
//class InlineEdit extends \Magento\Backend\App\Action
//{
//    protected $jsonFactory;
//    private $bannerFactory;
//    private $bannerResourceModel;
//
//    public function __construct(
//        Context $context,
//        JsonFactory $jsonFactory,
//        BannerFactory $bannerFactory,
//        BannerResourceModel $bannerResourceModel)
//    {
//        parent::__construct($context);
//        $this->jsonFactory = $jsonFactory;
//        $this->bannerFactory = $bannerFactory;
//        $this->bannerResourceModel = $bannerResourceModel;
//    }
//
//    public function execute()
//    {
//        $resultJson = $this->jsonFactory->create();
//        $error = false;
//        $messages = [];
//
//        if ($this->getRequest()->getParam('isAjax'))
//        {
//            $bannerItems = $this->getRequest()->getParam('items', []);
//            if (!count($bannerItems))
//            {
//                $messages[] = __('Please correct the data sent.');
//                $error = true;
//            }
//            else
//            {
//                foreach (array_keys($bannerItems) as $modelid)
//                {
//                    $model = $this->bannerFactory->create();
//                    $this->bannerResourceModel->load($model, $modelid);
//                    try
//                    {
//                        $model->setData(array_merge($model->getData(), $bannerItems[$modelid]));
//                        $this->bannerResourceModel->save($model);
//                    }
//                    catch (\Exception $e)
//                    {
//                        $messages[] = "[Error : {$modelid}]  {$e->getMessage()}";
//                        $error = true;
//                    }
//                }
//            }
//        }
//
//        return $resultJson->setData([
//            'messages' => $messages,
//            'error' => $error]);
//    }
//}


namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Dev\Banner\Model\Banner;

class InlineEdit extends Action
{
    protected $jsonFactory;
    protected $model;

    public function __construct(
        Context     $context,
        JsonFactory $jsonFactory,
        Model       $model
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->model = $model;
    }

    public function execute()
    {
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];
        if ($this->getRequest()->getParam('isAjax')) {
            $postItems = $this->getRequest()->getParam('items', []);
            if (empty($postItems)) {
                $messages[] = __('Please correct the data sent.');
                $error = true;
            } else {
                foreach (array_keys($postItems) as $bannerId) {
                    $modelData = $this->model->load($bannerId);
                    try {
                        $modelData->setData(array_merge($modelData->getData(), $postItems[$bannerId]));
                        $modelData->save();
                    } catch (\Exception $e) {
                        $messages[] = "[Error:]  {$e->getMessage()}";
                        $error = true;
                    }
                }
            }
        }

        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }
}
