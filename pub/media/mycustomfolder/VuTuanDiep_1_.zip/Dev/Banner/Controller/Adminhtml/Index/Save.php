<?php
////
////namespace Dev\Banner\Controller\Adminhtml\Index;
////
////use Dev\Banner\Model\BannerFactory;
////use Magento\Backend\App\Action;
////
/////**
//// * Class Save
//// * @package Dev\Banner\Controller\Adminhtml\Index
//// */
////class Save extends Action
////{
////    /**
////     * @var BannerFactory
////     */
////    private BannerFactory $bannerFactory;
////
////    /**
////     * @param Action\Context $context
////     * @param BannerFactory $bannerFactory
////     */
////    public function __construct(
////        Action\Context $context,
////        BannerFactory  $bannerFactory
////    ) {
////        parent::__construct($context);
////        $this->bannerFactory = $bannerFactory;
////    }
////
////    /**
////     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
////     */
////    public function execute()
////    {
//////        $data = $this->getRequest()->getPostValue();
//////        $banner_id = !empty($data['banner_id']) ? $data['banner_id'] : null;
//////
//////        $newData = [
//////            'name' => $data['name'],
//////            'description' => $data['description'],
//////            'image'=>$data['image'],
//////            'status' => $data['status'],
//////        ];
//////
//////        $banner = $this->bannerFactory->create();
//////
//////        if ($banner) {
//////            $banner->load($banner_id);
//////        }
//////        $data['image'] = $data['image'][0]['name'];
//////        try {
//////            if (isset($data['image']) && is_array($data['image'])) {
//////            $strpos = strpos($data['image'][0]['url'], '/media/');
//////            $data['image'][0]['url'] = substr($data['image'][0]['url'], $strpos + 6);
//////            $data['image'][0]['url'] = trim($data['image'][0]['url'], '/');
//////            $newData['image'] = json_encode($data['image']);
//////        }
//////            $banner->addData($newData);
//////            $banner->save();
////        ////            var_dump($newData);
////        ////            die();
//////            $this->messageManager->addSuccessMessage(__('You saved the banner.'));
//////        }
//////        catch (\Exception $e) {
//////            $this->messageManager->addErrorMessage(__($e->getMessage()));
//////        }
//////
//////
//////
////        ////            var_dump($data['image']);
////        ////            die();
//////
//////
//////            $this->getMessageManager()->addSuccessMessage(__('successful'));
//////            return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
//////
//////            $this->getMessageManager()->addErrorMessage(__('Save failure.'));
//////
//////
//////        return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
////        $data = $this->getRequest()->getPostValue();
////        $id = !empty($data['banner_id']) ? $data['banner_id'] : null;
////
////        $newData = [
////            'name' => $data['name'],
////            'description' => $data['description'],
////            'image' => $data['image'],
////            'status' => $data['status'],
////
////        ];
////
////        $banner = $this->bannerFactory->create();
////
////        if ($id) {
////            $banner->load($id);
////        }
////        try {
////            if (isset($data['image']) && is_array($data['image'])) {
////                $strpos = strpos($data['image'][0]['url'], '/media/');
////                $data['image'][0]['url'] = substr($data['image'][0]['url'], $strpos + 6);
////                $data['image'][0]['url'] = trim($data['image'][0]['url'], '/');
////                $newData['image'] = json_encode($data['image']);
////            }
////            $banner->addData($newData);
////            $banner->save();
////            $this->messageManager->addSuccessMessage(__('You saved the post.'));
////            return $this->resultRedirect->create()->setPath('dev_banner/index/save');
////        } catch (\Exception $e) {
////            $this->messageManager->addErrorMessage(__($e->getMessage()));
////        }
////
////        return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
////    }
////}
//
//namespace Dev\Banner\Controller\Adminhtml\Index;
//
//use Dev\Banner\Model\BannerFactory;
//use Magento\Backend\App\Action;
//
///**
// * Class Save
// * @package Dev\Banner\Controller\Adminhtml\Index
// */
//class Save extends Action
//{
//    /**
//     * @var BannerFactory
//     */
//    private BannerFactory $bannerFactory;
//
//    /**
//     * @param Action\Context $context
//     * @param BannerFactory $bannerFactory
//     */
//    public function __construct(
//        Action\Context $context,
//        BannerFactory  $bannerFactory
//    ) {
//        parent::__construct($context);
//        $this->bannerFactory = $bannerFactory;
//    }
//
//    /**
//     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
//     */
//    public function execute()
//    {
//        $data = $this->getRequest()->getPostValue();
//        $banner_id = !empty($data['banner_id']) ? $data['banner_id'] : null;
//
//        $newData = [
//            'name' => $data['name'],
//            'description' => $data['description'],
//            'image' => $data['image'],
//            'status' => $data['status'],
//        ];
//
//        $banner = $this->bannerFactory->create();
//
//        if ($banner_id) {
//            $banner->load($banner_id);
//        }
//        try {
//            if (isset($data['image']) && is_array($data['image'])) {
//                $strpos = strpos($data['image'][0]['url'], '/media/');
//                $data['image'][0]['url'] = substr($data['image'][0]['url'], $strpos + 6);
//                $data['image'][0]['url'] = trim($data['image'][0]['url'], '/');
//                $newData['image'] = json_encode($data['image']);
//            }
//
//            $banner->addData($newData);
//            $banner->save();
////            echo "<pre>";
////            var_dump($newData);
////            echo "<pre>";
////            die();
//            $this->messageManager->addSuccessMessage(__('You saved the banner.'));
//        } catch (\Exception $e) {
//            $this->messageManager->addErrorMessage(__($e->getMessage()));
//        }
////        echo "<pre>";
////        var_dump($newData);
////        echo "<pre>";
////        die();
//
////        try {
//////            var_dump($newData);
//////            die();
//////            $banner->addData($newData);
//////            $banner->save();
////            $this->getMessageManager()->addSuccessMessage(__('Thành công'));
////            return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
////        } catch (\Exception $e) {
////            $this->getMessageManager()->addErrorMessage(__('Save thất bại.'));
////        }
//
//        return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
//
//    }
//}

namespace Dev\Banner\Controller\Adminhtml\Index;

use Dev\Banner\Model\BannerFactory;
use Magento\Backend\App\Action;

/**
 * Class Save
 * @package Dev\Banner\Controller\Adminhtml\Index
 */
class Save extends Action
{
    /**
     * @var BannerFactory
     */
    private BannerFactory $bannerFactory;

    /**
     * @param Action\Context $context
     * @param BannerFactory $bannerFactory
     */
    public function __construct(
        Action\Context $context,
        BannerFactory  $bannerFactory
    ) {
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $banner_id = !empty($data['banner_id']) ? $data['banner_id'] : null;

        $newData = [
            'name' => $data['name'],
            'description' => $data['description'],
            'image' => $data['image'],
            'status' => $data['status'],
        ];

        $banner = $this->bannerFactory->create();
        if ($banner) {
            $banner->load($banner_id);
        }
        try {
            $banner->addData($newData);
            $banner->save();
            $this->messageManager->addSuccessMessage(__('You saved the banner.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }
        try {
            if (isset($data['image']) && is_array($data['image'])) {
                $strpos = strpos($data['image'][0]['url'], '/media/');
                $data['image'][0]['url'] = substr($data['image'][0]['url'], $strpos + 6);
                $data['image'][0]['url'] = trim($data['image'][0]['url'], '/');
                $newData['image'] = json_encode($data['image']);
            }

            $banner->addData($newData);
            $banner->save();
//            $this->getMessageManager()->addSuccessMessage(__('Thành công'));
//            return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
        }
        catch (\Exception $e) {
            $this->getMessageManager()->addErrorMessage(__('Save successful'));
        }
        return $this->resultRedirectFactory->create()->setPath('dev_banner/index/index');
    }
}
