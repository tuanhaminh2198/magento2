<?php

namespace Dev\Banner\Api\Data;

/**
 * Interface BannerSearchResultInterface
 * @package Dev\CustomApi\Api\Data
 */
interface BannerSearchResultInterface extends \Magento\Framework\Api\SearchResultsInterface
{


    /**
     * @return \Magento\Framework\Api\ExtensibleDataInterface[]
     */
    public function getItems();


    /**
     * @param array $items
     * @return BannerSearchResultInterface
     */
    public function setItems(array $items);

}
