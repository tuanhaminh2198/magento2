<?php

namespace Dev\Banner\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface BannerInterface
 * @package Dev\Banner\Api\Data
 */
interface BannerInterface extends ExtensibleDataInterface
{

    /**
     * @return int
     */
    public function getBannerId();

    /**
     * @param $bannerId
     * @return int
     */
    public function setBannerId($bannerId);


    /**
     * @return mixed
     */
    public function getName();


    /**
     * @param $name
     * @return string
     */
    public function setName($name);


    /**
     * @return string
     */
    public function getDescription();


    /**
     * @param $description
     * @return string
     */
    public function setDescription($description);


    /**
     * @return string
     */
    public function getImage();


    /**
     * @param $image
     * @return string
     */
    public function setImage($image);


    /**
     * @return string
     */
    public function getStatus();


    /**
     * @param $status
     * @return string
     */
    public function setStatus($status);
    /**
     * @return string
     */
}
