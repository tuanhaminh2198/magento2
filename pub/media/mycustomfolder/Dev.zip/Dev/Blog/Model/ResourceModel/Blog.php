<?php
namespace Dev\Blog\Model\ResourceModel;
class Blog extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb{
    protected function _construct()
    {
        $this->_init('blog', 'blog_id');
        // TODO: Implement _construct() method.
    }
}
