<?php
namespace Dev\Banner\Model\Config;
use Magento\Framework\Data\OptionSourceInterface;
class Color implements OptionSourceInterface
{
    protected $attributeOptionsList = [];
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $this->attributeOptionsList = [
            [
                'value' => "Test 1",
                "label" => "Test 1",
                "__disableTmpl" => 1,
                "optgroup" => [
                    [
                        'value' => "Test 1.1",
                        "label" => "Test 1.1",
                        "__disableTmpl" => 1,
                    ],
                ],
            ],
        ];
        return $this->attributeOptionsList;
    }
}
