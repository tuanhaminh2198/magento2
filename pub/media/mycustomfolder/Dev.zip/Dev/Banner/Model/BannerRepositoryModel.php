<?php
namespace Dev\Banner\Model;
use Magento\Framework\Exception\NoSuchEntityException;

class BannerRepositoryModel implements \Dev\Banner\Api\BannerRepositoryInterface{

    protected $_bannerModel;
    protected $_bannerResourceModel;
    protected $_bannerCollection;

    public function __construct(\Dev\Banner\Model\BannerFactory $bannerFactory,
    \Dev\Banner\Model\ResourceModel\BannerFactory $bannerResourceModelFactory,
    \Dev\Banner\Model\ResourceModel\Banner\CollectionFactory $collectionFactory
    ){
        $this->_bannerModel = $bannerFactory;
        $this->_bannerResourceModel = $bannerResourceModelFactory;
        $this->_bannerCollection = $collectionFactory;
    }

    public function getById($id)
    {
        $bannerModel = $this->_bannerModel->create()->load($id);
        if(empty($bannerModel)){
            throw new NoSuchEntityException(__('Unable to find custom data with ID "%1"', $id));
        }
        return $bannerModel;
        // TODO: Implement getById() method.
    }

}
