<?php
namespace Dev\Banner\Controller\Adminhtml\Index;
use Magento\Backend\App\Action\Context;
use Magento\Setup\Exception;

class InlineEdit extends \Magento\Backend\App\Action{

    protected $_jsonFactory;
    protected $_bannerFactory;
    protected $_bannerResourceModel;
    protected $_pageFactory;

    public function __construct(Context $context,
    \Magento\Framework\Controller\Result\JsonFactory $jsonFactory,
    \Dev\Banner\Model\BannerFactory $bannerFactory,
    \Dev\Banner\Model\ResourceModel\BannerFactory $bannerResourceFactory
    )
    {
        $this->_jsonFactory = $jsonFactory;
        $this->_bannerFactory = $bannerFactory;
        $this->_bannerResourceModel = $bannerResourceFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        echo "khiem";
        exit();
        $resultJson = $this->_jsonFactory->create();
        $error = false;
        $messages = [];

        if($this->getRequest()->getParam('isAjax'))
        {
            $bannerItems = $this->getRequest()->getParam('items', []);
            if(!count($bannerItems)){
                $messages[] = __("Please correct the data sent.");
                $error = true;
            }else{
                foreach (array_keys($bannerItems) as $modelid ){
                    $model = $this->_bannerFactory->create();
                    $this->_bannerResourceModel->load($model, $modelid);
                    try {
                        $model->setData(array_merge($model->getData(), $bannerItems[$modelid]));
                        $this->_bannerResourceModel->save($model);
                    }catch (Exception $exception){
                        $messages[] = "[Error : {$modelid}]  {$exception->getMessage()}";
                        $error = true;
                    }
                }
            }
            return $resultJson->setData([
                'messages' => $messages,
                'error' => $error]);
        }
//        // TODO: Implement execute() method.
    }

}
