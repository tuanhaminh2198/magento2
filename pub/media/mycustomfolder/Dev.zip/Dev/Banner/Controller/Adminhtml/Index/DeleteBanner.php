<?php

namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Dev\Banner\Model\ResourceModel\Banner\CollectionFactory;
use Dev\Banner\Model\BannerFactory;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class DeleteBanner extends Action
{
    private $bannerFactory;
    private $filter;
    private $collectionFactory;
    private $resultRedirect;

    protected $_filesystem;
    protected $_file;

    public function __construct(
        Action\Context $context,
        BannerFactory $bannerFactory,
        Filter $filter,
        CollectionFactory $collectionFactory,
        RedirectFactory $redirectFactory,
        Filesystem $_filesystem,
        File $file

    )
    {
        $this->_filesystem = $_filesystem;
        $this->_file = $file;
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->resultRedirect = $redirectFactory;
    }

    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $total = 0;
        $err = 0;
        foreach ($collection->getItems() as $item) {
            $deleteBanner = $this->bannerFactory->create()->load($item->getData('banner_id'));
            $dataBanner = $deleteBanner->getData();
//            if(!empty($dataBanner['file'])){
//                $infoFile = json_decode($dataBanner['file'], true);
//                $fileName = $infoFile['name'];
////                $filePath = $infoFile['path'];
//                $mediaRootDir = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
//                var_dump($mediaRootDir."/banner_folder/".$fileName);
//                die();
//                if($this->_file->isExists($mediaRootDir."/banner_folder/".$fileName)){
//                    $this->_file->deleteFile($mediaRootDir."/banner_folder/".$fileName);
//                }
//            }
            try {
                $deleteBanner->delete();
                $total++;
            } catch (LocalizedException $exception) {
                $err++;
            }
        }

        if ($total) {
            $this->messageManager->addSuccessMessage(
                __('A total of %1 record(s) have been deleted.', $total)
            );
        }

        if ($err) {
            $this->messageManager->addErrorMessage(
                __(
                    'A total of %1 record(s) haven\'t been deleted. Please see server logs for more details.',
                    $err
                )
            );
        }
        return $this->resultRedirect->create()->setPath('banner');
    }
}
