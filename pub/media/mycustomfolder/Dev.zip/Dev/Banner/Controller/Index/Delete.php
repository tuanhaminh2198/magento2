<?php
namespace Dev\Banner\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Setup\Exception;

class Delete extends \Magento\Framework\App\Action\Action{

    protected $_bannerFactory;
    protected $_redirectFactory;

    public function __construct(Context $context, \Dev\Banner\Model\BannerFactory $bannerFactory,
    \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory
    )
    {
        $this->_redirectFactory = $redirectFactory;
        $this->_bannerFactory = $bannerFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        if(!isset($id) || !is_numeric($id)){
            $this->messageManager->addErrorMessage('Id không hợp lệ');
            return $this->_redirectFactory->create()->setPath('banner');
        }else{
            $banner = $this->_bannerFactory->create()->load($id);
            if(empty($banner->getData())){
                $this->messageManager->addErrorMessage('Id không tồn tại');
                return $this->_redirectFactory->create()->setPath('banner');
            }else{
                $banner->delete();
                $this->messageManager->addSuccessMessage('Delete Success');
                return $this->_redirectFactory->create()->setPath('banner');
            }
        }
        // TODO: Implement execute() method.
    }

}
