<?php
namespace Dev\Banner\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Customer\Model\Customer;

class AddCustomerAttribute implements DataPatchInterface{

    private $customerSetupFactory;

    private $setup;

    private $eavConfig;

    public function __construct(
        \Magento\Framework\Setup\ModuleDataSetupInterface $moduleDataSetup,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
    ){
        $this->customerSetupFactory = $customerSetupFactory;
        $this->setup = $moduleDataSetup;
        $this->eavConfig = $eavConfig;
    }

    public function apply()
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->setup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType(Customer::ENTITY);
        $attributeSetId = $customerSetup->getDefaultAttributeSetId($customerEntity->getEntityTypeId());
        $attributeSetGroup = $customerSetup->getDefaultAttributeGroupId($customerEntity->getEntityTypeId(),$attributeSetId);
        $customerSetup->addAttribute(Customer::ENTITY,'customer_attribute',[
            'type' => 'varchar',
            'input' => 'text',
            'label' => 'Customer Attribute',
            'required' => true,
            'default' => 'khiemtv',
            'visible' => true,
            'user_defined' => true,
            'system' => false,
            'is_visible_in_grid' => true,
            'is_used_in_grid' => true,
            'is_filterable_in_grid' => true,
            'is_searchable_in_grid' => true,
            'position' => 300
        ]);
        $newAttribute = $this->eavConfig->getAttribute(Customer::ENTITY, 'customer_attribute');
        $newAttribute->addData([
            'used_in_forms' => ['adminhtml_checkout','adminhtml_customer','customer_account_edit','customer_account_create'],
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeSetGroup
        ]);
        $newAttribute->save();
        // TODO: Implement apply() method.
    }

    public static function getDependencies()
    {
        return [];
        // TODO: Implement getDependencies() method.
    }

    public function getAliases()
    {
        return [];
        // TODO: Implement getAliases() method.
    }

    public static function getVersion()
    {
        return '1.0.1';
    }
}
