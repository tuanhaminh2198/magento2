<?php
namespace Dev\Banner\Ui\Component\Listing\Column;

class OptionPosition implements \Magento\Framework\Data\OptionSourceInterface{

    public function toOptionArray()
    {
        return [
            ['value'=>0, 'label'=> __('After Page Header')] ,
            ['value'=>1, 'label'=>__('Before Page Footer')] ,
        ];
        // TODO: Implement toOptionArray() method.
    }

}
