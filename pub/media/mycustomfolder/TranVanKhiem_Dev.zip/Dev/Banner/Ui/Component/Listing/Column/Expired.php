<?php
namespace Dev\Banner\Ui\Component\Listing\Column;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;

class Expired extends \Magento\Ui\Component\Listing\Columns\Column{

    public function __construct(ContextInterface $context, UiComponentFactory $uiComponentFactory, array $components = [], array $data = [])
    {
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        foreach ($dataSource['data']['items'] as &$item){
            if (isset($item['expired'])){
                $expired = date_create($item['expired']);
                $day = date_format($expired,'d');
                $month = date_format($expired,'m');
                $year = date_format($expired,'Y');
                $item['expired'] = "$day/$month/$year";
            }
        }
        return $dataSource;
    }
}
