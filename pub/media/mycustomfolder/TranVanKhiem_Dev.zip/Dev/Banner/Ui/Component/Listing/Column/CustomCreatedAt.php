<?php
namespace Dev\Banner\Ui\Component\Listing\Column;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;

class CustomCreatedAt extends \Magento\Ui\Component\Listing\Columns\Column{

    public function __construct(ContextInterface $context, UiComponentFactory $uiComponentFactory, array $components = [], array $data = [])
    {
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        foreach ($dataSource['data']['items'] as &$item){
            if (isset($item['created_at'])){
                $created_at = date_create($item['created_at']);
                $day = date_format($created_at,'d');
                $month = date_format($created_at,'m');
                $year = date_format($created_at,'Y');
                $item['created_at'] = "Ngày: $day, Tháng: $month, Năm: $year";
            }
        }
        return $dataSource;
    }
}
