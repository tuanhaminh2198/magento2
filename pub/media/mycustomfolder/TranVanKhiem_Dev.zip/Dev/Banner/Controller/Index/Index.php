<?php
namespace Dev\Banner\Controller\Index;
use Magento\Framework\App\Action\Context;

class Index extends \Magento\Framework\App\Action\Action{
    protected $_pageFactory;
    protected $_bannerFactory;

    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $pageFactory,
                                \Dev\Banner\Model\BannerFactory $bannerFactory
    )
    {
        $this->_bannerFactory = $bannerFactory;
        $this->_pageFactory = $pageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        return $this->_pageFactory->create();
        // TODO: Implement execute() method.
    }
}
