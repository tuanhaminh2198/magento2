<?php
    namespace Dev\Banner\Controller\Index;

use Magento\Framework\App\Action\Context;

class TestPlugin extends \Magento\Framework\App\Action\Action{

    protected $pageFactory;

    public function __construct(Context $context, \Magento\Framework\Controller\Result\RawFactory $rawFactory)
    {
        $this->pageFactory = $rawFactory;
        parent::__construct($context);
    }

    public function execute()
    {
//        return $this->pageFactory->create()->setHeader('khiem','khiem');
        // TODO: Implement execute() method.
    }

}
