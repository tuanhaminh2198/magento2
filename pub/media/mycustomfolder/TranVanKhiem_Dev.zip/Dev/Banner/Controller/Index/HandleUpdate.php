<?php
namespace Dev\Banner\Controller\Index;

use Magento\Framework\App\Action\Context;

class HandleUpdate extends \Magento\Framework\App\Action\Action{
    protected $_redirectFactory;
    protected $_bannerRepositoryModel;
    protected $_coreRegistry;

    public function __construct(Context $context, \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory,
    \Magento\Framework\Registry $coreRegistry,
    \Dev\Banner\Model\BannerRepositoryModel $bannerRepositoryModel
    )
    {
        $this->_bannerRepositoryModel = $bannerRepositoryModel;
        $this->_coreRegistry = $coreRegistry;
        $this->_redirectFactory = $redirectFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = (int) $this->getRequest()->getParam('id');
        $data_banner = (array)$this->getRequest()->getPost();
        if ($data_banner) {
            $this->_bannerRepositoryModel->getById($id)->setData('name',$data_banner['name'])->save();
            $this->_bannerRepositoryModel->getById($id)->setData('image',$data_banner['image'])->save();
            $this->_bannerRepositoryModel->getById($id)->setData('status',$data_banner['status'])->save();
            $this->_bannerRepositoryModel->getById($id)->setData('short_description',$data_banner['short_description'])->save();
        }
        return $this->_redirectFactory->create()->setPath('banner');
        // TODO: Implement execute() method.
    }
}
