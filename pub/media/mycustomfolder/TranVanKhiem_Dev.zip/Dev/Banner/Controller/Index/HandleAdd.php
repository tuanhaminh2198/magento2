<?php
namespace Dev\Banner\Controller\Index;
use Magento\Framework\App\Action\Context;

class  HandleAdd extends \Magento\Framework\App\Action\Action{

    protected $_bannerFactory;
    protected $_redirectFactory;

    public function __construct(Context $context, \Dev\Banner\Model\BannerFactory $bannerFactory,
    \Magento\Framework\Controller\Result\RedirectFactory $redirectFactory
    )
    {
        $this->_redirectFactory = $redirectFactory;
        $this->_bannerFactory = $bannerFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $data_banner = (array)$this->getRequest()->getPost();
            if ($data_banner) {
                $model = $this->_bannerFactory->create()->setData($data_banner);
                $this->_eventManager->dispatch('change_name_frontend',['change_name'=>$model]);
                $model->save();
                $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __("We can\'t submit your request, Please try again."));
        }
        return $this->_redirectFactory->create()->setPath('banner');
    }

}
