<?php
namespace Dev\Banner\Controller\Index;
use Magento\Framework\App\Action\Context;

class TestRequireJS extends \Magento\Framework\App\Action\Action{
    protected $_pageFactory;
    protected $_jsonFactory;
    protected $_rawFactory;

    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $jsonFactory,
        \Magento\Framework\Controller\Result\RawFactory $rawFactory
    )
    {
        $this->_rawFactory = $rawFactory;
        $this->_jsonFactory = $jsonFactory;
        $this->_pageFactory = $pageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
//        return $this->_rawFactory->create()->setContents(123324);
//        return $this->_jsonFactory->create()->setHeader('abc','khem','anc')->setData(['k'=>'khiem']);
        return $this->_pageFactory->create();
        // TODO: Implement execute() method.
    }

}
