<?php

namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Dev\Banner\Model\ResourceModel\Banner\CollectionFactory;
use Dev\Banner\Model\BannerFactory;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class DeleteBanner extends Action
{
    private $bannerFactory;
    private $filter;
    private $collectionFactory;
    private $resultRedirect;

    protected $_filesystem;
    protected $_file;
    protected $_deleteFile;

    public function __construct(
        Action\Context $context,
        BannerFactory $bannerFactory,
        Filter $filter,
        CollectionFactory $collectionFactory,
        RedirectFactory $redirectFactory,
        Filesystem $_filesystem,
        File $file,
        \Dev\Banner\Block\DeleteFile $deleteFile
    )
    {
        $this->_filesystem = $_filesystem;
        $this->_file = $file;
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->resultRedirect = $redirectFactory;
        $this->_deleteFile = $deleteFile;
    }

    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $total = 0;
        $err = 0;
        foreach ($collection->getItems() as $item) {
            $deleteBanner = $this->bannerFactory->create()->load($item->getData('banner_id'));
            $dataBanner = $deleteBanner->getData();
            try {
                // xoas anhr
                if (isset($dataBanner['image']) && !empty($dataBanner['image'])) {
                    $this->_deleteFile->delete($dataBanner['image']);
                }
                $deleteBanner->delete();
                $total++;
            } catch (LocalizedException $exception) {
                $err++;
            }
        }

        if ($total) {
            $this->messageManager->addSuccessMessage(
                __('A total of %1 record(s) have been deleted.', $total)
            );
        }

        if ($err) {
            $this->messageManager->addErrorMessage(
                __(
                    'A total of %1 record(s) haven\'t been deleted. Please see server logs for more details.',
                    $err
                )
            );
        }
        return $this->resultRedirect->create()->setPath('banner');
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Dev_Banner::delete');
    }
}
