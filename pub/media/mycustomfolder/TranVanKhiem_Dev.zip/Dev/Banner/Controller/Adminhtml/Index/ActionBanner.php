<?php
namespace Dev\Banner\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;

class ActionBanner extends \Magento\Backend\App\Action{

    protected $_pageFactory;
    protected $bannerFactory;

    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $pageFactory,
    \Dev\Banner\Model\BannerFactory $bannerFactory
    )
    {
        $this->bannerFactory = $bannerFactory;
        $this->_pageFactory = $pageFactory;
        parent::__construct($context);
    }


    public function checkAcl(){
        $acl = 'Dev_Banner::add';
        $id = (!empty($this->getRequest()->getParam('id')))?$this->getRequest()->getParam('id'):null;
        if($id){
            $acl = 'Dev_Banner::edit';
        }
        return $acl;
    }

    public function execute()
    {
        $id = (!empty($this->getRequest()->getParam('id')))?$this->getRequest()->getParam('id'):null;
        $title = "Add Banner";
        if($id){
            $banner = $this->bannerFactory->create()->load($id)->getData();
            $title = $banner['name'];
        }
        $resultPage = $this->_pageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__($title));
        return $resultPage;
        // TODO: Implement execute() method.
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed($this->checkAcl());
    }

}
