var config = {
    map: {
        '*': {
            'Magento_Ui/js/grid/controls/columns':'Dev_Banner/js/grid/controls/columns'
        }
    },
    paths: {
        'ui/template/form/element/input': 'Dev_Banner/template/form/element/input'
    }
};
