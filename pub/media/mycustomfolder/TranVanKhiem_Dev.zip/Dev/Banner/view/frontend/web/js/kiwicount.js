define([
    'jquery'
], function ($, _) {
    'use strict';

    $.widget('mage.kiwicount',{
        _create: function(config,element) {
            this._case = $(this.element);
            $(this._case).keyup(function () {
                var max = config.maxlen;
                var len = $(this.element).length;
                if (len >= max) {
                    $('#'+config.messagebox).text(' you have reached the limit');
                } else {
                    var char = max - len;
                    $('#'+config.messagebox).text(char + ' characters left');
                }
            });
        }
    });
    return $.mage.kiwicount;
});
