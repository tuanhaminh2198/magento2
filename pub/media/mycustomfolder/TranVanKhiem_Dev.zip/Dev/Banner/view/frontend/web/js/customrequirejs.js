define([],function (){

    var custom = {};
    custom.getText = function (){
        return 'Test Require JS'
    }
    return custom;

});
