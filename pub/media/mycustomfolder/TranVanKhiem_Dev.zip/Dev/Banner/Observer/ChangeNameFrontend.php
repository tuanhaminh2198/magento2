<?php
namespace Dev\Banner\Observer;
use Magento\Framework\Event\Observer;

class ChangeNameFrontend implements \Magento\Framework\Event\ObserverInterface{

    public function execute(Observer $observer)
    {
        $data = $observer->getData('change_name');
//        var_dump($data);
//        die();
        $data->setData('name','Tôi đã thay đổi dữ liệu cột name khi dữ liệu được gửi.');
//        var_dump($data);
//        die();
        // TODO: Implement execute() method.
    }

}
