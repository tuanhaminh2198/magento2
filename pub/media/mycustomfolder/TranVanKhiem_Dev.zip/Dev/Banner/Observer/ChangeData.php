<?php
namespace Dev\Banner\Observer;
use Magento\Framework\Event\Observer;

class ChangeData implements \Magento\Framework\Event\ObserverInterface{

    public function execute(Observer $observer)
    {
        $data = $observer->getData('saveBanner');
//        var_dump($data);
//        die();
        $data->setData('name','Tôi đã thay đổi dữ liệu cột name khi dữ liệu được gửi.');
        $observer->setData('saveBanner', $data);
        // TODO: Implement execute() method.
    }

}
