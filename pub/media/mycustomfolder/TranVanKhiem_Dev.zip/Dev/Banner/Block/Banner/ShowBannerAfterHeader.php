<?php
namespace Dev\Banner\Block\Banner;
use Magento\Framework\View\Element\Template;

class ShowBannerAfterHeader extends \Magento\Framework\View\Element\Template{

    public function __construct(Template\Context $context, array $data = [],
    \Dev\Banner\Model\ResourceModel\Banner\CollectionFactory $collectionFactory)
    {
        $this->bannerCollectionFactory = $collectionFactory;
        parent::__construct($context, $data);
    }

    protected function _beforeToHtml()
    {
        $collection = $this->bannerCollectionFactory->create();
        $banners = $collection->addFieldToFilter('status',['eq' => true])->addFieldToFilter('position',['eq' => 0])->getData();
        $this->setData('banners',$banners);
        $this->setData('mediaURL', $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA));
        return parent::_beforeToHtml();
    }

}
