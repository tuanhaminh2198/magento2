<?php
namespace Dev\Banner\Block;
use Magento\Framework\View\Element\Template;

class Banner extends \Magento\Framework\View\Element\Template{
    protected $_bannerFactory;
    protected $_coreRegistry;
    protected $_bannerRepositoryModel;

    public function __construct(Template\Context $context, array $data = [],
    \Dev\Banner\Model\BannerFactory $bannerFactory,
    \Magento\Framework\Registry $coreRegistry,
    \Dev\Banner\Model\BannerRepositoryModel $bannerRepositoryModel
    )
    {
        $this->_bannerRepositoryModel = $bannerRepositoryModel;
        $this->_coreRegistry = $coreRegistry;
        $this->_bannerFactory = $bannerFactory;
        parent::__construct($context, $data);
    }

    public function show_banner(){
        $id = $this->_coreRegistry->registry('id');
        if(isset($id) && is_numeric($id)){
            $banner_id = $this->_bannerFactory->create()->getCollection()->load($id)->getData();
            if(empty($banner_id)){
               return  $this->messageManager->addErrorMessage(__("Khong co ban ghi nao"));
            }else{
                return $this->_bannerFactory->create()->getCollection()->addFieldToFilter(['name'],['like'=>'%khiem%'])->getFirstItem()->getData();
            }
        }else{
            // Để sử dụng sắp xếp gọi method setOrder(),
            // Để sử dụng lọc gọi đến method addFieldToFilter(),
            // Để sử dụng limit gọi đến method setPageSize(), lấy ra
            return $this->_bannerFactory->create()->getCollection()->addFieldToFilter('status',1)->setPageSize(3)->setCurPage(0)->getData();
        }
    }

    public function getBannerById(){
        $id = $this->_coreRegistry->registry('id');
        $banner = $this->_bannerRepositoryModel->getById($id);
        return $banner;
    }

}
