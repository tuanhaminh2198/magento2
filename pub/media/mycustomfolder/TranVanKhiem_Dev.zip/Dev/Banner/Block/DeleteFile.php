<?php
namespace Dev\Banner\Block;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class DeleteFile extends Action
{
    protected $fileSystem;
    protected $file;

    public function __construct(Context $context, File $file, Filesystem $fileSystem)
    {
        $this->file = $file;
        $this->fileSystem = $fileSystem;
        parent::__construct($context);
    }

    public function delete($fileName){
        $mediaRootDir = $this->fileSystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
        if ($this->file->isExists($mediaRootDir . $fileName)) {
            $this->file->deleteFile($mediaRootDir . $fileName);
        }
    }

    public function execute()
    {
        // TODO: Implement execute() method.
    }

}
