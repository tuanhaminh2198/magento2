<?php
namespace Dev\Banner\Plugin\Block\Banner;
class Index {

//    protected $bannerFactory;
//
//    public function __construct(\Dev\Banner\Model\BannerFactory $bannerFactory)
//    {
//            $this->bannerFactory = $bannerFactory;
//    }
    public function beforeExecute(){
       $name = "Tran Van Khiem";
       return $name;
    }
}
