<?php
    namespace Dev\Banner\Plugin\Block\Banner;

    class GetBannerById{

//        Phuuowng thức before sẽ chạy trước phương thức mà nó tác động đến, tên phải trùng với tên function
// tác động cùng với tiền tố before đứng trước. Nếu không có đối số truyền vào nó sẽ trả về một đối số có giá trị null
        public function beforeGetById($id){
           return $id = 2 ;
        }

//        Ngược lại với before, phương thức after sẽ được chạy sau khi phương thức gốc đã chạy xong. PHương thức này
    // Bắt buộc phải có giá trị trả về và phải có tên trùng với phương thức gốc với tiền tố là after ,
        // sử dụng after để thay đổi giá trị trả về của phương thức gốc bằng cách thay đổi nó và trả về giá trị đã thay đổi ở cuối phwuong thức
//        public function afterGetById(){
//            return [];
//        }

// Phương thức around sẽ chạy trước và sau phương thức ban đầu. Nó cho phép sửa đổi đối số đầu vào, kết quả trả về
// hoặc thậm chí ghi đè lên phương thức ban đầu
// Phương thức around có điểm đặc biệt đó là callable. Nó sẽ nhận một callable có thể gọi đến phương thức tiếp
// theo trong chuỗi hoặc phương thức ban đầu. Nếu callable không được gọi thì tất cả các phương thức tiếp theo trong chuỗi sex khoohng chạy
// Sử dụng để ghi đề phương thức gốc
//        public function aroundGetById($id, $bannerModel){
//            return
//        }
    }
