<?php
namespace Dev\Banner\Plugin\Block\Banner;
class CustomShowBanner{

    protected $_bannerRepositoryModel;
    protected $_coreRegistry;

    public function __construct(
        \Dev\Banner\Model\BannerRepositoryModel $bannerRepositoryModel,
        \Magento\Framework\Registry $coreRegistry
    ){
        $this->_bannerRepositoryModel = $bannerRepositoryModel;
        $this->_coreRegistry = $coreRegistry;
    }

    public function afterGetBannerById(){
//        $id = 5;
//        return $this->_bannerRepositoryModel->getById($id);
        return ['banner_id'=>4,
        'name' => 'test',
        'image' => 'abc.jpg',
        'status' => 1,
        'short_description' => 'anc'
        ];
    }

}
