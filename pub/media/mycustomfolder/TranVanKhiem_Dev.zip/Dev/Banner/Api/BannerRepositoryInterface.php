<?php
namespace Dev\Banner\Api;

interface BannerRepositoryInterface{

    public function getById($id);

}
