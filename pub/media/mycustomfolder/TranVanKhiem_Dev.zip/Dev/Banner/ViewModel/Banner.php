<?php
namespace Dev\Banner\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;

class Banner implements ArgumentInterface
{
    protected $bannerFactory;

    public function __construct(\Dev\Banner\Model\BannerFactory $bannerFactory) {
        $this->bannerFactory = $bannerFactory;
    }

    public function getBannerById($id)
    {
        $banner = $this->bannerFactory->create()->load($id);
        return $banner;
    }
}
