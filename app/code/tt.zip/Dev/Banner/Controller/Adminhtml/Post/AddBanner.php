<?php
////
////namespace Dev\Banner\Controller\Adminhtml\Post;
////
////use Dev\Banner\Model\PostFactory;
////use Magento\Backend\App\Action;
////
/////**
//// * Class Save
//// * @package ViMagento\HelloWorld\Controller\Adminhtml\Post
//// */
////class AddBanner extends Action
////{
////    /**
////     * @var PostFactory
////     */
////    private $postFactory;
////
////    /**
////     * Save constructor.
////     * @param Action\Context $context
////     * @param PostFactory $postFactory
////     */
////    public function __construct(
////        Action\Context $context,
////        PostFactory $postFactory
////    ) {
////        parent::__construct($context);
////        $this->postFactory = $postFactory;
////    }
////
////    public function execute()
////
////    {
////        $data = $this->getRequest()->getPostValue();
////        $id = !empty($data['post_id']) ? $data['post_id'] : null;
////
////        $newData = [
////            'name' => $data['name'],
////            'image'=>$data['image'],
//////            'status' => $data['status'],
////            'description' => $data['description'],
////        ];
////
////        $post = $this->postFactory->create();
////
////        if ($id) {
////            $post->load($id);
////        }
////        try {
////            $post->addData($newData);
////            $post->save();
////            $this->messageManager->addSuccessMessage(__('You saved the post.'));
////        } catch (\Exception $e) {
////            $this->messageManager->addErrorMessage(__($e->getMessage()));
////        }
////
////        return $this->resultRedirectFactory->create()->setPath('banner/post/index');
////    }
////}
//
//
//namespace Dev\Banner\Controller\Adminhtml\Post;
//
//use Magento\Framework\App\Action\Action;
//use Magento\Framework\App\Action\Context;
//use Magento\Framework\Controller\ResultFactory;
//use Magento\Framework\UrlInterface;
//use Magento\Framework\View\Result\PageFactory;
//use Dev\Banner\Model\PostFactory;
//
//
//class AddBanner extends Action
//{
//    protected $resultPageFactory;
//
//    private $extensionFactory;
//
//    private $url;
//
//    public function __construct(UrlInterface $url, PostFactory $extensionFactory, Context $context, PageFactory $resultPageFactory)
//    {
//        parent::__construct($context);
//        $this->resultPageFactory = $resultPageFactory;
//        $this->extensionFactory = $extensionFactory;
//        $this->url = $url;
//    }
//
//    public function execute()
//    {
//        $data = $this->getRequest()->getParams();
//        $model = $this->extensionFactory->create();
//        $model->setData($data)->save();
//        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
//        $resultRedirect->setUrl("banner/post");
//        return $resultRedirect;
//    }
//}

namespace Dev\Banner\Controller\Adminhtml\Post;

use Dev\Banner\Model\PostFactory;
use Magento\Backend\App\Action;

/**
 * Class Save
 * @package ViMagento\HelloWorld\Controller\Adminhtml\Post
 */
class AddBanner extends Action
{
    /**
     * @var PostFactory
     */
    private $postFactory;

    /**
     * Save constructor.
     * @param Action\Context $context
     * @param PostFactory $postFactory
     */
    public function __construct(
        Action\Context $context,
        PostFactory $postFactory
    ) {
        parent::__construct($context);
        $this->postFactory = $postFactory;
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $id = !empty($data['banner_id']) ? $data['banner_id'] : null;
        $newData = [
            'name' => $data['name'],
            'status' => $data['status'],
            'short_description' => $data['short_description'],
            'description' => $data['description']

        ];

        $post = $this->postFactory->create();

        if ($id) {
            $post->load($id);
        }
        try {
            $post->addData($newData);
            $post->save();
            $this->messageManager->addSuccessMessage(__('You saved the post.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }

        return $this->resultRedirectFactory->create()->setPath('banner/post/index');
    }
}
